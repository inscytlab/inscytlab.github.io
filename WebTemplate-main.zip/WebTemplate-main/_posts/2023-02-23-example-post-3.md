---
title: Example post 3
image: images/photo.jpg
author: john-doe
tags: biology, medicine
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
