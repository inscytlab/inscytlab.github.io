---
name: John Doe
image: images/photo.jpg
role: phd
group: alum
links:
  github: john-doe
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
