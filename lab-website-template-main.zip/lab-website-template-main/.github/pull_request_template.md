STOP!!!

You are about to open this pull request against THE TEMPLATE ITSELF. You probably meant to open it against your own website repo.

---

FOR THE TEMPLATE MAINTAINER(S)

New template version checklist:

- [ ] I have updated CITATION and CHANGELOG as appropriate.
- [ ] I have updated lab-website-template-docs as appropriate.
- [ ] I have checked the testbed as appropriate.
